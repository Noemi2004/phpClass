<?php
include 'db_connection.php';

$recid = $_GET['recid'];
$query = "SELECT * FROM events WHERE recid = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $recid);
$stmt->execute();
$result = $stmt->get_result();
$event

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['honeypot'])) {
        die("Bot detected!");}
        $recid = $_POST['recid'];
        $eventName = $_POST['eventName'];
        $eventDate = $_POST['eventDate'];

        $query = "UPDATE events SET eventName = ?, eventDate = ? WHERE recid = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssi", $eventName, $eventDate, $recid);

        if ($stmt->execute()) {
            echo "Event updated successfully!";
        } else {
            echo "Error updating event: " . $stmt->error;}}
?>

